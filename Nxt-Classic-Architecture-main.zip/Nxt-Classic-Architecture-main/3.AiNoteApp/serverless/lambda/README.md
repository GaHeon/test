3티어 아키텍처 기본 실습

- zip -r index.zip .
- aws lambda update-function-code --function-name MyFunction --zip-file fileb://index.zip
