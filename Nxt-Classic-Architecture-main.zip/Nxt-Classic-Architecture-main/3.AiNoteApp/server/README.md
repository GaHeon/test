데이터베이스 구성 선행
디펜던시 설치 : `npm install express mysql openai dotenv cors`
